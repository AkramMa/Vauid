'use strict';

const speakeasy = require('speakeasy');
const QRCode = require('qrcode');

class TwoFAManager {
  /**
   * Generate a new TOTP secret for an account
   */
  static generateSecret(label = 'VauID', issuer = 'VauID') {
    const secret = speakeasy.generateSecret({
      name: label,
      issuer,
      length: 20,
    });
    return {
      secret: secret.base32,
      otpauth: secret.otpauth_url,
    };
  }

  /**
   * Generate QR code data URL for the OTPAuth URL
   */
  static async generateQR(otpauth) {
    return await QRCode.toDataURL(otpauth, {
      width: 200,
      margin: 2,
      color: { dark: '#ffffff', light: '#0d0f14' },
    });
  }

  /**
   * Verify a TOTP token against a secret
   */
  static verifyToken(secret, token) {
    return speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token: String(token).replace(/\s/g, ''),
      window: 1,
    });
  }

  /**
   * Generate current TOTP value (for display in vault)
   */
  static generateTOTP(secret) {
    const token = speakeasy.totp({
      secret,
      encoding: 'base32',
    });
    // Return token + seconds remaining
    const epoch = Math.round(new Date().getTime() / 1000);
    const remaining = 30 - (epoch % 30);
    return { token, remaining };
  }

  /**
   * Parse OTPAuth URL into components
   */
  static parseOTPAuth(url) {
    try {
      const u = new URL(url);
      const secret = u.searchParams.get('secret');
      const issuer = u.searchParams.get('issuer') || '';
      const label = decodeURIComponent(u.pathname.slice(1)).replace(/^.*:/, '');
      return { secret, issuer, label };
    } catch {
      return null;
    }
  }
}

module.exports = TwoFAManager;
