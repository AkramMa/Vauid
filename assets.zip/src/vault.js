'use strict';

// vault.js — VaultManager backed by KeePassXC .kdbx files (kdbxweb)
//
// Reads ANY .kdbx file (KeePassXC, KeePass 2.x, KeeWeb, etc.)
// Writes kdbx4 + Argon2id — same default as KeePassXC 2.7+
//
// KeePassXC field mapping:
//   Title, UserName, Password, URL, Notes  → standard KeePass fields
//   TOTP  → 'otp' field  (otpauth:// URI — KeePassXC native format)
//   Tags  → entry.tags   (string array)
//   Folders → KeePass groups (no extra metadata needed)
//   Custom fields → any non-standard field key on the entry
//   Attachments   → entry.binaries (await db.createBinary())
//   Type / app meta → 'vd_type', 'vd_json' custom fields (invisible to KeePassXC)

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

if (!global.crypto) global.crypto = crypto.webcrypto;

const { Kdbx, KdbxCredentials, ProtectedValue, CryptoEngine } = require('kdbxweb');

// Wire argon2 — required for KeePassXC databases (Argon2id default)
try {
  const argon2 = require('argon2');
  CryptoEngine.setArgon2Impl(async (password, salt, memory, iterations, length, parallelism, type, version) => {
    const variant = type === 2 ? argon2.argon2id
      : type === 1 ? argon2.argon2i
        : argon2.argon2d;
    const hash = await argon2.hash(Buffer.from(password), {
      salt: Buffer.from(salt),
      memoryCost: Math.max(8, memory),          // already in KiB — do NOT divide
      timeCost: Math.max(1, iterations),
      parallelism: Math.max(1, parallelism),     // use the actual parallelism arg
      hashLength: length,
      type: variant,
      raw: true,
    });
    return hash.buffer.slice(hash.byteOffset, hash.byteOffset + hash.byteLength);
  });
} catch (_) {
  // argon2 not installed — kdbx3/AES-KDF files still open
  // kdbx4/Argon2 files (KeePassXC default) will throw ARGON2_UNAVAILABLE
}


// ── Constants ─────────────────────────────────────────────────────────────────
const VAULT_EXT = '.kdbx';
const META_FILE = 'vauid.meta.json';
const PIN_FILE = 'vauid.pin.json';
const APP_DATA = path.join(os.homedir(), '.vauid');
const RECENT_FILE = path.join(APP_DATA, 'recent.json');

// Standard KeePass fields — everything else is a custom field
const STD_FIELDS = new Set(['Title', 'UserName', 'Password', 'URL', 'Notes', 'otp']);
// Our private metadata prefix (invisible to KeePassXC but survives round-trips)
const VD = 'vd_';

// ── Helpers ───────────────────────────────────────────────────────────────────
function pv(str) { return ProtectedValue.fromString(str || ''); }
function uuidHex(uuid) { return Buffer.from(uuid.id).toString('hex'); }
function toAB(buf) { return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength); }

function readField(entry, name) {
  const v = entry.fields.get(name);
  if (v == null) return '';
  return typeof v.getText === 'function' ? v.getText() : String(v);
}

// ── VaultManager ──────────────────────────────────────────────────────────────
class VaultManager {
  constructor() {
    this._vaultPath = null;
    this._db = null;
    this._credentials = null;
    this._currentPassword = null;
    this._unlocked = false;
    this._onAfterSave = null;
    if (!fs.existsSync(APP_DATA)) fs.mkdirSync(APP_DATA, { recursive: true });
  }

  setAfterSaveHook(fn) { this._onAfterSave = fn; }

  // ── Create ────────────────────────────────────────────────────────────────
  async create(folderPath, password, hint = '') {
    const name = path.basename(folderPath);
    const vaultPath = path.join(folderPath, `${name}${VAULT_EXT}`);
    const creds = new KdbxCredentials(pv(password));
    const db = Kdbx.create(creds, name);

    // kdbx4 + Argon2id — same as KeePassXC defaults
    db.upgrade();

    // Store app settings in db customData (invisible to KeePassXC)
    db.meta.customData.set('vd_settings',
      JSON.stringify({ autoLock: 5, theme: 'dark', language: 'en', trashDays: 30 }));

    const buf = Buffer.from(await db.save());
    fs.writeFileSync(vaultPath, buf);
    fs.writeFileSync(
      path.join(folderPath, META_FILE),
      JSON.stringify({ hint, createdAt: new Date().toISOString(), version: 4 }, null, 2)
    );
    this._vaultPath = vaultPath; this._db = db; this._credentials = creds;
    this._currentPassword = password; this._unlocked = true;
    this._saveRecent(vaultPath);
    return { success: true, vaultPath };
  }

  // ── Open ──────────────────────────────────────────────────────────────────
  open(vaultPath) {
    if (!fs.existsSync(vaultPath)) throw new Error('FILE_NOT_FOUND');
    if (!vaultPath.endsWith(VAULT_EXT)) throw new Error('INVALID_FILE');
    this._vaultPath = vaultPath; this._unlocked = false; this._db = null;
    this._saveRecent(vaultPath);
    const metaPath = path.join(path.dirname(vaultPath), META_FILE);
    let hint = '';
    if (fs.existsSync(metaPath)) {
      try { hint = JSON.parse(fs.readFileSync(metaPath, 'utf8')).hint || ''; } catch { }
    }
    return { success: true, hint };
  }

  // ── Unlock ────────────────────────────────────────────────────────────────
  async unlock(password) {
    if (!this._vaultPath) throw new Error('NO_VAULT');
    const fileBuf = fs.readFileSync(this._vaultPath);
    const creds = new KdbxCredentials(pv(password));
    let db;
    try {
      db = await Kdbx.load(toAB(fileBuf), creds);
    } catch (err) {
      const code = err.code || '';
      const msg = err.message || '';
      if (code === 'InvalidKey' || msg.includes('InvalidKey')) throw new Error('WRONG_PASSWORD');
      if (code === 'NotImplemented' || msg.includes('argon2 not impl')) throw new Error('ARGON2_UNAVAILABLE');
      throw err;
    }
    this._db = db;
    this._credentials = creds;
    this._currentPassword = password;
    this._unlocked = true;
    await this._purgeTrash();
    return { success: true };
  }

  // ── Unlock with PIN ───────────────────────────────────────────────────────
  async unlockWithPin(pin) {
    if (!this._vaultPath) throw new Error('NO_VAULT');
    const pinPath = path.join(path.dirname(this._vaultPath), PIN_FILE);
    if (!fs.existsSync(pinPath)) throw new Error('NO_PIN_SET');
    const pinData = JSON.parse(fs.readFileSync(pinPath, 'utf8'));
    const failures = pinData.failures || 0, lockedAt = pinData.lockedAt || 0;
    const LOCK_MS = 30_000, MAX = 5, REVOKE = 10;
    if (failures >= REVOKE) { try { fs.unlinkSync(pinPath); } catch { } throw new Error('PIN_REVOKED'); }
    if (lockedAt && Date.now() - lockedAt < LOCK_MS)
      throw new Error(`PIN_LOCKED:${Math.ceil((LOCK_MS - (Date.now() - lockedAt)) / 1000)}`);
    if (!pinData.v || pinData.v < 2) { try { fs.unlinkSync(pinPath); } catch { } throw new Error('PIN_UPGRADE_REQUIRED'); }
    const inputHash = this._hashPin(pin, pinData.salt);
    if (inputHash !== pinData.hash) {
      const nf = failures + 1;
      fs.writeFileSync(pinPath, JSON.stringify({ ...pinData, failures: nf, lockedAt: nf % MAX === 0 ? Date.now() : 0 }));
      if (nf >= REVOKE) throw new Error('PIN_REVOKED');
      if (nf % MAX === 0) throw new Error('PIN_LOCKED:30');
      throw new Error('WRONG_PIN');
    }
    const { failures: _f, lockedAt: _l, ...clean } = pinData;
    fs.writeFileSync(pinPath, JSON.stringify(clean));
    return this.unlock(this._decryptPinMaster(pinData.encMaster, pin));
  }

  // ── Set PIN ───────────────────────────────────────────────────────────────
  setPin(pin) {
    if (!this._unlocked) throw new Error('LOCKED');
    const salt = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(
      path.join(path.dirname(this._vaultPath), PIN_FILE),
      JSON.stringify({
        v: 2, hash: this._hashPin(pin, salt), salt,
        encMaster: this._encryptPinMaster(this._currentPassword, pin)
      })
    );
    return { success: true };
  }

  hasPinFile() {
    return !!(this._vaultPath && fs.existsSync(path.join(path.dirname(this._vaultPath), PIN_FILE)));
  }

  lock() {
    this._db = null; this._credentials = null;
    this._unlocked = false; this._currentPassword = null;
    return { success: true };
  }

  // ── Save ──────────────────────────────────────────────────────────────────
  async save(overrideData) {
    if (!this._unlocked || !this._vaultPath) throw new Error('LOCKED');
    if (overrideData?.settings)
      this._db.meta.customData.set('vd_settings', JSON.stringify(overrideData.settings));
    const buf = Buffer.from(await this._db.save());
    const tmp = this._vaultPath + '.tmp';
    fs.writeFileSync(tmp, buf);
    fs.renameSync(tmp, this._vaultPath);
    if (this._onAfterSave) try { this._onAfterSave(this._vaultPath); } catch { }
    return { success: true };
  }

  getData() {
    if (!this._unlocked) throw new Error('LOCKED');
    return this._snapshot();
  }

  isUnlocked() { return this._unlocked; }
  getVaultPath() { return this._vaultPath; }
  getVaultFolder() { return this._vaultPath ? path.dirname(this._vaultPath) : null; }

  // ── Items CRUD ────────────────────────────────────────────────────────────
  async addItem(item) {
    if (!this._unlocked) throw new Error('LOCKED');
    // Place in the correct group (folder) or root
    const group = item.folderId ? (this._findGroup(item.folderId) || this._rootGroup()) : this._rootGroup();
    const entry = this._db.createEntry(group);
    const id = uuidHex(entry.uuid);
    const newItem = {
      ...item, id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      folderId: item.folderId || null,
      favorite: item.favorite || false,
    };
    this._writeEntry(entry, newItem);
    await this.save();
    return newItem;
  }

  async updateItem(id, updates) {
    if (!this._unlocked) throw new Error('LOCKED');
    const entry = this._findEntry(id);
    if (!entry) throw new Error('ITEM_NOT_FOUND');
    const current = this._readEntry(entry);
    const updated = { ...current, ...updates, updatedAt: new Date().toISOString() };
    this._writeEntry(entry, updated);
    // Handle folder move
    if (updates.folderId !== undefined && updates.folderId !== current.folderId) {
      const targetGroup = updates.folderId ? (this._findGroup(updates.folderId) || this._rootGroup()) : this._rootGroup();
      this._db.move(entry, targetGroup);
    }
    await this.save();
    return updated;
  }

  async deleteItem(id) {
    if (!this._unlocked) throw new Error('LOCKED');
    const entry = this._findEntry(id);
    if (entry) {
      const recycleBin = this._getOrCreateRecycleBin();
      entry.fields.set(`${VD}deletedAt`, new Date().toISOString());
      this._db.move(entry, recycleBin);
    }
    await this.save();
    return { success: true };
  }

  async deleteFromTrash(id) {
    if (!this._unlocked) throw new Error('LOCKED');
    const bin = this._getRecycleBin();
    if (bin) {
      const e = this._findInGroup(bin, id);
      if (e) this._db.remove(e);
    }
    await this.save();
    return { success: true };
  }

  async restoreFromTrash(id) {
    if (!this._unlocked) throw new Error('LOCKED');
    const bin = this._getRecycleBin();
    if (!bin) throw new Error('NOT_IN_TRASH');
    const e = this._findInGroup(bin, id);
    if (!e) throw new Error('NOT_IN_TRASH');
    e.fields.delete(`${VD}deletedAt`);
    this._db.move(e, this._rootGroup());
    await this.save();
    return { success: true };
  }

  async emptyTrash() {
    if (!this._unlocked) throw new Error('LOCKED');
    const bin = this._getRecycleBin();
    if (bin) [...bin.entries].forEach(e => this._db.remove(e));
    await this.save();
    return { success: true };
  }

  async _purgeTrash() {
    const days = this._settings().trashDays ?? 30;
    if (!days) return;
    const cutoff = Date.now() - days * 86_400_000;
    const bin = this._getRecycleBin();
    if (!bin) return;
    let removed = false;
    [...bin.entries].forEach(e => {
      const d = readField(e, `${VD}deletedAt`);
      if (d && new Date(d).getTime() < cutoff) { this._db.remove(e); removed = true; }
    });
    if (removed) await this.save();
  }

  // ── Folders — backed by KeePass groups ───────────────────────────────────
  async addFolder(folder) {
    if (!this._unlocked) throw new Error('LOCKED');
    const g = this._db.createGroup(this._rootGroup(), folder.name || 'New Folder');
    const id = uuidHex(g.uuid);
    // Store colour in group customData so it round-trips
    g.customData.set('vd_color', folder.color || '#6366f1');
    g.customData.set('vd_createdAt', new Date().toISOString());
    const nf = { ...folder, id, createdAt: new Date().toISOString(), color: folder.color || '#6366f1' };
    await this.save();
    return nf;
  }

  async updateFolder(id, updates) {
    if (!this._unlocked) throw new Error('LOCKED');
    const g = this._findGroup(id);
    if (!g) throw new Error('FOLDER_NOT_FOUND');
    if (updates.name) g.name = updates.name;
    if (updates.color) g.customData.set('vd_color', updates.color);
    await this.save();
    return { id, name: g.name, color: g.customData.get('vd_color') || '#6366f1' };
  }

  async deleteFolder(id) {
    if (!this._unlocked) throw new Error('LOCKED');
    const g = this._findGroup(id);
    if (g) {
      [...g.entries].forEach(e => {
        e.fields.delete(`${VD}folderId`);
        this._db.move(e, this._rootGroup());
      });
      this._db.remove(g);
    }
    await this.save();
    return { success: true };
  }

  // ── Attachments ───────────────────────────────────────────────────────────
  async addAttachment(itemId, filePath) {
    if (!this._unlocked) throw new Error('LOCKED');
    const entry = this._findEntry(itemId);
    if (!entry) throw new Error('ITEM_NOT_FOUND');
    const buf = fs.readFileSync(filePath);
    const name = path.basename(filePath);
    const aId = crypto.randomUUID();
    // MUST await db.createBinary — it returns a Promise
    const bin = await this._db.createBinary(buf);
    entry.binaries.set(`${aId}::${name}`, bin);
    // Track metadata in a private field
    const meta = this._attachMeta(entry);
    meta[aId] = { id: aId, name, size: buf.length, type: path.extname(filePath), addedAt: new Date().toISOString() };
    entry.fields.set(`${VD}attachMeta`, JSON.stringify(meta));
    await this.save();
    return { success: true, attachId: aId };
  }

  exportAttachment(itemId, attachId, destPath) {
    if (!this._unlocked) throw new Error('LOCKED');
    const entry = this._findEntry(itemId);
    if (!entry) throw new Error('ITEM_NOT_FOUND');
    for (const [key, ref] of entry.binaries) {
      if (key.startsWith(attachId + '::')) {
        const val = ref?.value;
        const data = val instanceof ArrayBuffer ? Buffer.from(val)
          : val?.getBinary ? Buffer.from(val.getBinary())
            : Buffer.from(val);
        fs.writeFileSync(destPath, data);
        return { success: true };
      }
    }
    throw new Error('ATTACHMENT_NOT_FOUND');
  }

  async removeAttachment(itemId, attachId) {
    if (!this._unlocked) throw new Error('LOCKED');
    const entry = this._findEntry(itemId);
    if (!entry) throw new Error('ITEM_NOT_FOUND');
    // Remove the binary from the kdbx entry
    for (const key of entry.binaries.keys()) {
      if (key.startsWith(attachId + '::')) {
        entry.binaries.delete(key);
        break;
      }
    }
    // Remove from attachment metadata
    const meta = this._attachMeta(entry);
    delete meta[attachId];
    if (Object.keys(meta).length > 0) {
      entry.fields.set(`${VD}attachMeta`, JSON.stringify(meta));
    } else {
      entry.fields.delete(`${VD}attachMeta`);
    }
    await this.save();
    return { success: true };
  }

  // ── Password change ───────────────────────────────────────────────────────
  async changePassword(oldPw, newPw) {
    if (!this._unlocked) throw new Error('LOCKED');
    if (oldPw !== this._currentPassword) {
      try { await Kdbx.load(toAB(fs.readFileSync(this._vaultPath)), new KdbxCredentials(pv(oldPw))); }
      catch { throw new Error('WRONG_PASSWORD'); }
    }
    this._credentials = new KdbxCredentials(pv(newPw));
    this._currentPassword = newPw;
    this._db.credentials = this._credentials;
    await this.save();
    const p = path.join(path.dirname(this._vaultPath), PIN_FILE);
    if (fs.existsSync(p)) fs.unlinkSync(p);
    return { success: true };
  }

  // ── Export / Import ───────────────────────────────────────────────────────
  exportData(format = 'json') {
    if (!this._unlocked) throw new Error('LOCKED');
    const { items } = this._snapshot();
    if (format === 'json') return JSON.stringify(items, null, 2);
    const rows = [['Name', 'URL', 'Username', 'Password', 'Notes']];
    items.filter(i => i.type === 'login').forEach(l =>
      rows.push([l.name, l.url || '', l.username || '', l.password || '', l.notes || ''])
    );
    return rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
  }

  async importData(rawJson) {
    if (!this._unlocked) throw new Error('LOCKED');
    const items = JSON.parse(rawJson);
    if (!Array.isArray(items)) throw new Error('INVALID_FORMAT');
    for (const item of items) {
      const e = this._db.createEntry(this._rootGroup());
      const id = uuidHex(e.uuid);
      this._writeEntry(e, {
        ...item, id,
        importedAt: new Date().toISOString(),
        createdAt: item.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        folderId: null,
        favorite: item.favorite || false,
      });
    }
    await this.save();
    return { success: true, count: items.length };
  }

  async reload() {
    if (!this._unlocked || !this._vaultPath || !this._currentPassword) return;
    try {
      const db = await Kdbx.load(toAB(fs.readFileSync(this._vaultPath)), new KdbxCredentials(pv(this._currentPassword)));
      this._db = db;
    } catch { }
  }

  // ── Recent vaults ─────────────────────────────────────────────────────────
  _saveRecent(p) {
    let r = this._loadRecents();
    r = [p, ...r.filter(x => x !== p)].slice(0, 5);
    fs.writeFileSync(RECENT_FILE, JSON.stringify(r));
  }
  _loadRecents() { try { return JSON.parse(fs.readFileSync(RECENT_FILE, 'utf8')); } catch { return []; } }
  getRecentVaults() { return this._loadRecents().filter(p => fs.existsSync(p)); }
  getHint() {
    const m = this._vaultPath ? path.join(path.dirname(this._vaultPath), META_FILE) : null;
    try { return m && fs.existsSync(m) ? JSON.parse(fs.readFileSync(m, 'utf8')).hint || '' : ''; } catch { return ''; }
  }

  // ── Private: group/entry navigation ──────────────────────────────────────

  // The root group is the database's default group (the named one at the top)
  _rootGroup() { return this._db.getDefaultGroup(); }

  // KeePassXC's Recycle Bin is a special group referenced in db.meta.recycleBinUuid
  _getRecycleBin() {
    const uuid = this._db.meta.recycleBinUuid;
    if (!uuid) return null;
    return this._walkGroups(this._rootGroup(), g =>
      Buffer.from(g.uuid.id).toString('hex') === Buffer.from(uuid.id).toString('hex')
    );
  }

  _getOrCreateRecycleBin() {
    const existing = this._getRecycleBin();
    if (existing) return existing;
    const bin = this._db.createGroup(this._rootGroup(), 'Recycle Bin');
    this._db.meta.recycleBinUuid = bin.uuid;
    this._db.meta.recycleBinEnabled = true;
    return bin;
  }

  _findGroup(id) {
    return this._walkGroups(this._rootGroup(), g => uuidHex(g.uuid) === id);
  }
  _walkGroups(g, pred) {
    if (pred(g)) return g;
    for (const c of g.groups) { const f = this._walkGroups(c, pred); if (f) return f; }
    return null;
  }

  _findEntry(id) {
    return this._walkEntries(this._rootGroup(), e => uuidHex(e.uuid) === id);
  }
  _findInGroup(g, id) { return this._walkEntries(g, e => uuidHex(e.uuid) === id); }
  _walkEntries(g, pred) {
    for (const e of g.entries) if (pred(e)) return e;
    for (const c of g.groups) { const f = this._walkEntries(c, pred); if (f) return f; }
    return null;
  }

  // ── Entry ↔ item mapping ──────────────────────────────────────────────────

  _writeEntry(entry, item) {
    // Standard KeePass fields
    entry.fields.set('Title', item.name || '');
    entry.fields.set('UserName', item.username || '');
    entry.fields.set('Password', pv(item.password || ''));
    entry.fields.set('URL', item.url || '');
    entry.fields.set('Notes', item.notes || '');

    // TOTP — stored as otpauth:// URI in 'otp' field (KeePassXC native format)
    if (item.totp) {
      // If it's already an otpauth URI keep it, otherwise wrap the secret
      const uri = item.totp.startsWith('otpauth://')
        ? item.totp
        : `otpauth://totp/${encodeURIComponent(item.name || 'Account')}?secret=${item.totp}&period=30&digits=6`;
      entry.fields.set('otp', pv(uri));
    } else {
      entry.fields.delete('otp');
    }

    // Tags (KeePassXC native)
    entry.tags = Array.isArray(item.tags) ? item.tags : [];

    // Custom fields from the customFields array (card, identity, SSH, etc.)
    const existingCustom = new Set();
    if (Array.isArray(item.customFields)) {
      for (const cf of item.customFields) {
        if (!cf.name) continue;
        existingCustom.add(cf.name);
        const val = cf.protected ? pv(cf.value || '') : (cf.value || '');
        entry.fields.set(cf.name, val);
      }
    }
    // Remove custom fields that were deleted
    for (const k of entry.fields.keys()) {
      if (!STD_FIELDS.has(k) && !k.startsWith(VD) && !existingCustom.has(k)) {
        entry.fields.delete(k);
      }
    }

    // Private app metadata (type, folderId, favorite, extra data)
    entry.fields.set(`${VD}type`, item.type || 'login');
    entry.fields.set(`${VD}folderId`, item.folderId || '');
    entry.fields.set(`${VD}favorite`, String(item.favorite || false));
    entry.fields.set(`${VD}createdAt`, item.createdAt || new Date().toISOString());
    entry.fields.set(`${VD}updatedAt`, item.updatedAt || new Date().toISOString());
    if (item.deletedAt) entry.fields.set(`${VD}deletedAt`, item.deletedAt);

    // Extra structured data (card numbers, identity fields, etc.)
    const blob = { ...item };
    ['password', 'totp', 'name', 'username', 'url', 'notes', 'tags', 'customFields'].forEach(k => delete blob[k]);
    entry.fields.set(`${VD}json`, JSON.stringify(blob));
  }

  _readEntry(entry) {
    let extra = {};
    try { extra = JSON.parse(readField(entry, `${VD}json`) || '{}'); } catch { }

    // Read all non-standard, non-private fields as customFields
    const customFields = [];
    for (const [k, v] of entry.fields) {
      if (STD_FIELDS.has(k) || k.startsWith(VD)) continue;
      const isProtected = v && typeof v.getText === 'function';
      customFields.push({
        name: k,
        value: isProtected ? v.getText() : String(v || ''),
        protected: isProtected,
      });
    }

    // Parse TOTP — return the secret if it's an otpauth URI, else as-is
    const otpRaw = readField(entry, 'otp');
    let totp = otpRaw;
    if (otpRaw && otpRaw.startsWith('otpauth://')) {
      try {
        const url = new URL(otpRaw);
        const secret = url.searchParams.get('secret');
        if (secret) totp = secret; // expose the raw secret for TOTP generation
      } catch { }
      // Also expose the full URI for display/editing
      extra.totpUri = otpRaw;
    }

    return {
      ...extra,
      id: uuidHex(entry.uuid),
      name: readField(entry, 'Title'),
      username: readField(entry, 'UserName'),
      password: readField(entry, 'Password'),
      url: readField(entry, 'URL'),
      notes: readField(entry, 'Notes'),
      totp: totp || extra.totp || '',
      tags: Array.isArray(entry.tags) ? entry.tags : [],
      customFields,
      type: readField(entry, `${VD}type`) || extra.type || 'login',
      folderId: readField(entry, `${VD}folderId`) || null,
      createdAt: readField(entry, `${VD}createdAt`) || extra.createdAt,
      updatedAt: readField(entry, `${VD}updatedAt`) || extra.updatedAt,
      favorite: readField(entry, `${VD}favorite`) === 'true',
      deletedAt: readField(entry, `${VD}deletedAt`) || undefined,
    };
  }

  _attachMeta(entry) {
    try { return JSON.parse(readField(entry, `${VD}attachMeta`) || '{}'); } catch { return {}; }
  }

  // ── Snapshot ──────────────────────────────────────────────────────────────

  _snapshot() {
    const root = this._rootGroup();
    const binUuid = this._db.meta.recycleBinUuid;
    const binHex = binUuid ? Buffer.from(binUuid.id).toString('hex') : null;

    // Collect folders (all sub-groups except Recycle Bin)
    const grpGet = (g, key) => {
      try { return (typeof g.customData?.get === 'function' ? g.customData.get(key) : g.customData?.[key]) || ''; }
      catch { return ''; }
    };
    const folders = root.groups
      .filter(g => uuidHex(g.uuid) !== binHex)
      .map(g => ({
        id: uuidHex(g.uuid),
        name: g.name,
        color: grpGet(g, 'vd_color') || '#6366f1',
        createdAt: grpGet(g, 'vd_createdAt') || '',
      }));

    // Collect all entries, separating trash
    const items = [], trash = [];
    const attachments = {};

    const walkAll = (group, isTrash) => {
      const isThisTrash = binHex && uuidHex(group.uuid) === binHex;
      for (const e of group.entries) {
        const item = this._readEntry(e);
        const meta = this._attachMeta(e);
        if (Object.keys(meta).length) attachments[item.id] = meta;
        if (isTrash || isThisTrash) trash.push(item);
        else items.push(item);
      }
      for (const child of group.groups) {
        walkAll(child, isTrash || isThisTrash);
      }
    };
    walkAll(root, false);

    return {
      version: 4, createdAt: '', updatedAt: new Date().toISOString(),
      items, trash, folders, attachments, settings: this._settings(),
    };
  }

  _settings() {
    try { return JSON.parse(this._db.meta.customData.get('vd_settings') || '{}'); }
    catch { return { autoLock: 5, theme: 'dark', language: 'en', trashDays: 30 }; }
  }

  // ── PIN crypto ────────────────────────────────────────────────────────────
  _hashPin(pin, salt) {
    return crypto.pbkdf2Sync(pin, salt, 600000, 32, 'sha512').toString('hex');
  }
  _encryptPinMaster(master, pin) {
    const salt = crypto.randomBytes(32), iv = crypto.randomBytes(12);
    // 600k iterations — consistent with vault key derivation and PIN hash
    const key = crypto.pbkdf2Sync(pin, salt, 600000, 32, 'sha512');
    const c = crypto.createCipheriv('aes-256-gcm', key, iv);
    const enc = Buffer.concat([c.update(master, 'utf8'), c.final()]);
    return Buffer.concat([salt, iv, c.getAuthTag(), enc]).toString('base64');
  }
  _decryptPinMaster(b64, pin) {
    const buf = Buffer.from(b64, 'base64');
    const salt = buf.slice(0, 32), iv = buf.slice(32, 44);
    const tag = buf.slice(44, 60), enc = buf.slice(60);
    // 600k iterations — consistent with vault key derivation and PIN hash
    const key = crypto.pbkdf2Sync(pin, salt, 600000, 32, 'sha512');
    const d = crypto.createDecipheriv('aes-256-gcm', key, iv); d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
  }
}

module.exports = VaultManager;
