'use strict';

// ─────────────────────────────────────────────────────────────────────────────
// preload.js — Secure bridge between main process and renderer
//
// Exposes a narrow, typed API via contextBridge so the renderer never touches
// Node.js or Electron internals directly.
// ─────────────────────────────────────────────────────────────────────────────

const { contextBridge, ipcRenderer } = require('electron');

// Helper: wrap an IPC channel into a one-liner invoke call
const invoke = (channel, ...args) => ipcRenderer.invoke(channel, ...args);

// Channels the renderer is allowed to listen on (allowlist)
const ALLOWED_EVENTS = [
  'tray:lock', 'vault:status', 'vault:updated', 'sync:status',
  'ws:pairingCode', 'ws:sessions', 'ws:credentialDetected',
];

contextBridge.exposeInMainWorld('vauid', {

  // ── Window controls ─────────────────────────────────────────────────────────
  window: {
    minimize:    () => invoke('window:minimize'),
    maximize:    () => invoke('window:maximize'),
    close:       () => invoke('window:close'),
    isMaximized: () => invoke('window:isMaximized'),
  },

  // ── Vault management ────────────────────────────────────────────────────────
  vault: {
    create:         (folderPath, password, hint) => invoke('vault:create', folderPath, password, hint),
    open:           (filePath)                   => invoke('vault:open',   filePath),
    unlock:         (password)                   => invoke('vault:unlock', password),
    unlockWithPin:  (pin)                        => invoke('vault:unlockWithPin', pin),
    lock:           ()                           => invoke('vault:lock'),
    save:           (data)                       => invoke('vault:save',   data),
    getData:        ()                           => invoke('vault:getData'),
    setPin:         (pin)                        => invoke('vault:setPin', pin),
    changePassword: (oldPw, newPw)               => invoke('vault:changePassword', oldPw, newPw),
    getHint:        ()                           => invoke('vault:getHint'),
    isUnlocked:     ()                           => invoke('vault:isUnlocked'),
    pickFolder:     ()                           => invoke('vault:pickFolder'),
    openFile:       ()                           => invoke('vault:openFile'),
    getRecentVaults: ()                          => invoke('vault:getRecentVaults'),
    getVaultFolder:  ()                          => invoke('vault:getVaultFolder'),
    exportData:     (format)                     => invoke('vault:exportData', format),
    importData:     (filePath)                   => invoke('vault:importData', filePath),
  },

  // ── Trash ───────────────────────────────────────────────────────────────────
  trash: {
    getAll:        ()    => invoke('trash:getAll'),
    restore:       (id)  => invoke('trash:restore',       id),
    deleteForever: (id)  => invoke('trash:deleteForever', id),
    empty:         ()    => invoke('trash:empty'),
  },

  // ── Items CRUD ──────────────────────────────────────────────────────────────
  items: {
    add:          (item)              => invoke('items:add',          item),
    update:       (id, updates)       => invoke('items:update',       id, updates),
    delete:       (id)                => invoke('items:delete',       id),
    getAll:       ()                  => invoke('items:getAll'),
    moveToFolder: (id, folderId)      => invoke('items:moveToFolder', id, folderId),
  },

  // ── Folders ─────────────────────────────────────────────────────────────────
  folders: {
    add:    (folder)          => invoke('folders:add',    folder),
    update: (id, updates)     => invoke('folders:update', id, updates),
    delete: (id)              => invoke('folders:delete', id),
    getAll: ()                => invoke('folders:getAll'),
  },

  // ── Password tools ───────────────────────────────────────────────────────────
  password: {
    generate:         (options) => invoke('password:generate',         options),
    strength:         (pwd)     => invoke('password:strength',         pwd),
    checkBreach:      (pwd)          => invoke('password:checkBreach',      pwd),
    checkEmailBreach: (email, apiKey) => invoke('password:checkEmailBreach', email, apiKey || ''),
  },

  // ── Two-factor authentication ────────────────────────────────────────────────
  twofa: {
    generateSecret: (label, issuer) => invoke('twofa:generateSecret', label, issuer),
    verifyToken:    (secret, token) => invoke('twofa:verifyToken',    secret, token),
    generateQR:     (otpauth)       => invoke('twofa:generateQR',     otpauth),
    generateTOTP:   (secret)        => invoke('twofa:generateTOTP',   secret),
  },

  // ── Cloud sync ──────────────────────────────────────────────────────────────
  sync: {
    configure:  (provider, config) => invoke('sync:configure', provider, config),
    push:       ()                  => invoke('sync:push'),
    pull:       ()                  => invoke('sync:pull'),
    getStatus:  ()                  => invoke('sync:getStatus'),
    disconnect: ()                  => invoke('sync:disconnect'),
  },

  // ── File attachments ─────────────────────────────────────────────────────────
  attachments: {
    add:      (itemId, filePath)           => invoke('attachments:add',      itemId, filePath),
    remove:   (itemId, attachId)           => invoke('attachments:remove',   itemId, attachId),
    export:   (itemId, attachId, destPath) => invoke('attachments:export',   itemId, attachId, destPath),
    pickFile: ()                           => invoke('attachments:pickFile'),
  },

  // ── Clipboard ───────────────────────────────────────────────────────────────
  clipboard: {
    write: (text) => invoke('clipboard:write', text),
    clear: ()     => invoke('clipboard:clear'),
  },

  // ── Shell / OS ──────────────────────────────────────────────────────────────
  shell: {
    openExternal: (url) => invoke('shell:openExternal', url),
    openPath:     (p)   => invoke('shell:openPath',     p),
    getHome:      ()    => invoke('shell:getHome'),
  },

  // ── Extension WebSocket bridge ───────────────────────────────────────────────
  ws: {
    getStatus:           ()          => invoke('ws:getStatus'),
    generatePairingCode: ()          => invoke('ws:generatePairingCode'),
    revokeSession:       (profileId) => invoke('ws:revokeSession', profileId),
    restart:             (port)      => invoke('ws:restart', port),
  },

  // ── Event bus (main → renderer) ─────────────────────────────────────────────
  // Only channels in ALLOWED_EVENTS can be subscribed to.
  on(channel, callback) {
    if (ALLOWED_EVENTS.includes(channel)) {
      ipcRenderer.on(channel, (_e, ...args) => callback(...args));
    }
  },
  off(channel, callback) {
    ipcRenderer.removeListener(channel, callback);
  },
});
